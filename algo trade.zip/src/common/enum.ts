export const userType = {
    owner: 0,
    user: 2
}